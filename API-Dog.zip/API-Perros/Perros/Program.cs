﻿using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace Practica
{
    class RickAPI
    {
        static async Task Main(string[] args)
        {
            List<DogRace> characters = new List<DogRace>();

            while (true)
            {
                await ShowMenu(characters);
            }
        }

        static async Task ShowMenu(List<DogRace> characters)
        {
            Console.WriteLine("================");
            Console.WriteLine("1. Buscar raza de perro");
            Console.WriteLine("2. Listar razas guardadas");
            Console.WriteLine("3. Salir");
            Console.WriteLine("================\n");

            string option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.Write("Raza de Perro: ");
                    string? breed = Console.ReadLine();

                    if (!string.IsNullOrEmpty(breed))
                    {
                        var dog = await GetDogAsync(breed);

                        if (dog != null)
                        {
                            Console.WriteLine("\n===========================");
                            Console.WriteLine($"Raza: {breed.ToLower()}");
                            Console.WriteLine($"Imagen: {dog.ImageUrl}");
                            Console.WriteLine("===========================\n");

                            string addToList;

                            do
                            {
                                Console.WriteLine("¿Quieres guardarlo en tu lista? (s/n)");
                                addToList = Console.ReadLine();

                            } while (addToList.ToLower().Trim() != "s" && addToList.ToLower().Trim() != "n");

                            if (addToList == "s"){
                                characters.Add(dog);
                                Console.WriteLine("La raza se ha añadido correctamente a la lista\n");
                            }
                            else{
                                Console.WriteLine("La raza no se ha añadido a la lista");
                            }

                        } else {
                            Console.WriteLine($"No se encontró la raza \"{breed}\" en la API.");
                        }
                    }

                    break;

                case "2":
                    if (characters.Count == 0)
                    {
                        Console.WriteLine("No tienes ninguna raza guardada.");
                        break;
                    }

                    Console.WriteLine("=== RAZAS GUARDADAS ===");

                    for (int i = 0; i < characters.Count; i++)
                    {
                        var dog = characters[i];
                        Console.WriteLine($"{i + 1}. {dog.Race} --> {dog.ImageUrl}");
                    }

                    Console.WriteLine("\n");
                    break;

                case "3":
                    Console.WriteLine("Saliendo...");
                    Environment.Exit(0);
                    break;

                default:
                    Console.WriteLine("Opción inválida");
                    break;
            }
        }

        static async Task<DogRace?> GetDogAsync(string breed)
        {
            try
            {
                HttpClient client = new HttpClient();

                var response = await client.GetAsync(
                    $"https://dog.ceo/api/breed/{breed.ToLower()}/images/random"
                );

                if (!response.IsSuccessStatusCode)
                    return null;

                var content = await response.Content.ReadAsStringAsync();

                var apiResponse = JsonSerializer.Deserialize<DogApiResponse>(content);

                if (apiResponse == null || apiResponse.Status != "success")
                    return null;

                return new DogRace
                {
                    Race = breed.ToLower(), ImageUrl = apiResponse.Message
                };
            }
            catch
            {
                return null;
            }
        }
    }
}

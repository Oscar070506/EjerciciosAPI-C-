using System.Text.Json.Serialization;

public class DogRace
{
    public string Race { get; set; }
    public string ImageUrl { get; set; }
}

public class DogApiResponse
{
    [JsonPropertyName("message")]
    public string? Message { get; set; }

    [JsonPropertyName("status")]
    public string? Status { get; set; }
}
﻿using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;


namespace Practica
{
    class RickAPI
    {

        static async Task Main(string[] args){

            List<Results> characters = new List<Results>();

            while (true)
            {
                await ShowMenu(characters);
            }
        }

        static async Task ShowMenu(List<Results> characters)
        {
            Console.WriteLine("================");
            Console.WriteLine("1. Buscar personaje por nombre");
            Console.WriteLine("2. Listar Personajes Guardados");
            Console.WriteLine("3. Salir");
            Console.WriteLine("================\n");

            string option = Console.ReadLine();

            switch (option)
            {
                case "1":
                    Console.Write("Nombre del Personaje: ");
                    string? name = Console.ReadLine();

                    if (!string.IsNullOrEmpty(name))
                    {
                            var character = await GetCharacterAsync(name);
                            if(character != null)
                            {
                            Console.WriteLine("\n===========================");
                            Console.WriteLine($"Nombre: {character.Name}");
                            Console.WriteLine($"Esado: {character.Status}");
                            Console.WriteLine($"Especie: {character.Species}");
                            Console.WriteLine($"Género: {character.Gender}");
                            Console.WriteLine("===========================\n");
                            }

                            string addToList;

                        do
                        {
                            Console.WriteLine("¿Quieres guardarlo en tu lista? (s/n)");
                            addToList = Console.ReadLine();

                        } while (addToList.ToLower().Trim() != "s" && addToList.ToLower().Trim() != "n");

                        if (addToList == "s"){
                            characters.Add(character);
                            Console.WriteLine("El personaje se ha añadido correctamente a la lista\n");

                        } else if(addToList == "n"){
                            Console.WriteLine("El personaje no se ha añadido a la lista");
                        }

                    } else { Console.WriteLine($"No se encontro a \"{name}\" en la API");}

                    break;

                case "2":
                    Console.WriteLine("=== MIS PERSONAJES ===");
                    for (int i = 0; i < characters.Count; i++)
                    {
                        var character = characters[i];
                        Console.WriteLine($"{i + 1}. {character.Name} ({character.Species} - {character.Status})");
                    }
                    Console.WriteLine("\n");
                    break;

                case "3":
                    Console.WriteLine("Saliendo...");
                    break;

                default:
                    break;
            }
        }


        static async Task<Results?> GetCharacterAsync(string name)
        {
            try
            {
                HttpClient client = new HttpClient();

                var response = await client.GetAsync(
                    $"https://rickandmortyapi.com/api/character/?name={name.ToLower()}"
                );

                if (!response.IsSuccessStatusCode) return null;

                var content = await response.Content.ReadAsStringAsync();

                var apiResponse = JsonSerializer.Deserialize<APIResponse>(content);

                return apiResponse?.Results?.FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }

    }
}
